# THEA Infinity

## Overview

THEA Infinity is a one-page marketing website for a student-focused technology and career guidance startup. The platform offers industry-relevant tech courses, placement-focused training, and expert mentorship to help students build skills and careers. The website features a modern, animated design with sections for Hero, About, Services, and Contact, following a vibrant educational tech aesthetic.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Build Tool**: Vite for development and production builds
- **Routing**: Wouter for lightweight client-side routing (single-page app with hash navigation for sections)
- **State Management**: TanStack React Query for server state and API calls
- **Styling**: Tailwind CSS with CSS variables for theming (dark mode by default)
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Animations**: Framer Motion for smooth transitions and scroll-based animations
- **Forms**: React Hook Form with Zod validation using @hookform/resolvers
- **Typography**: Poppins (headings) and Inter (body) from Google Fonts

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript compiled with tsx
- **API Pattern**: RESTful JSON API with `/api` prefix
- **Validation**: Zod schemas for request validation with zod-validation-error for error messages
- **Build Process**: esbuild for server bundling, Vite for client bundling

### Data Storage
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Location**: `shared/schema.ts` - shared between frontend and backend
- **Current Storage**: MemStorage class for development (in-memory)
- **Database Ready**: PostgreSQL schema defined with drizzle-kit for migrations
- **Tables**: Users table and Contact Submissions table

### Project Structure
```
├── client/           # React frontend
│   ├── src/
│   │   ├── components/ui/  # shadcn/ui components
│   │   ├── hooks/          # Custom React hooks
│   │   ├── lib/            # Utilities and query client
│   │   └── pages/          # Page components
├── server/           # Express backend
│   ├── index.ts      # Server entry point
│   ├── routes.ts     # API route definitions
│   ├── storage.ts    # Data storage layer
│   └── vite.ts       # Vite dev server integration
├── shared/           # Shared code between frontend/backend
│   └── schema.ts     # Drizzle schemas and Zod types
└── attached_assets/  # Static images and assets
```

### Design System
- **Color Theme**: Orange primary color matching the THEA logo
- **Dark Mode**: Default theme with CSS variable-based theming
- **Component Style**: shadcn/ui "new-york" style variant
- **Spacing**: Tailwind spacing primitives (4, 6, 8, 12, 16, 20)
- **Border Radius**: Custom values (lg: 9px, md: 6px, sm: 3px)

## External Dependencies

### UI Framework
- **Radix UI**: Full suite of accessible primitive components (dialog, dropdown, tabs, etc.)
- **shadcn/ui**: Pre-styled component library configuration in `components.json`
- **Lucide React**: Icon library for consistent iconography

### Data & Forms
- **TanStack React Query**: Async state management and API caching
- **React Hook Form**: Form state management
- **Zod**: Schema validation shared across frontend and backend
- **Drizzle Zod**: Generate Zod schemas from Drizzle table definitions

### Database
- **PostgreSQL**: Target database (requires DATABASE_URL environment variable)
- **Drizzle ORM**: Type-safe database queries
- **Drizzle Kit**: Database migrations and schema push

### Development Tools
- **Vite**: Frontend dev server with HMR
- **tsx**: TypeScript execution for server
- **esbuild**: Production server bundling
- **Replit Plugins**: Dev banner, cartographer, and runtime error overlay for Replit environment