import { useState, useEffect, useRef } from "react";
import { motion, useInView, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { insertContactSchema, type InsertContact } from "@shared/schema";
import { 
  Menu, 
  X, 
  Users, 
  Target, 
  GraduationCap, 
  Lightbulb, 
  Brain, 
  Code, 
  Globe, 
  Rocket, 
  FolderOpen,
  Mail,
  Phone,
  ArrowRight,
  ChevronUp,
  Infinity as InfinityIcon
} from "lucide-react";
import heroImage from "@assets/stock_images/business_professiona_5988846b.jpg";
import contactImage from "@assets/stock_images/students_studying_la_83993214.jpg";

function Logo({ size = "md" }: { size?: "sm" | "md" | "lg" }) {
  const sizes = {
    sm: { icon: "w-5 h-5", text: "text-sm" },
    md: { icon: "w-6 h-6", text: "text-base" },
    lg: { icon: "w-8 h-8", text: "text-lg" },
  };
  
  return (
    <div className="flex items-center gap-1.5">
      <InfinityIcon className={`${sizes[size].icon} text-primary`} strokeWidth={2} />
      <span className={`${sizes[size].text} font-normal tracking-wide text-foreground`}>THEA</span>
    </div>
  );
}

const navLinks = [
  { name: "Home", href: "#home" },
  { name: "About", href: "#about" },
  { name: "Services", href: "#services" },
  { name: "Contact", href: "#contact" },
];

const aboutPoints = [
  {
    icon: Users,
    title: "Student-First Approach",
    description: "Every program is designed with students' learning pace, career goals, and confidence in mind."
  },
  {
    icon: Target,
    title: "Placement-Focused Training",
    description: "Structured preparation for interviews, aptitude, problem-solving, and resume building."
  },
  {
    icon: GraduationCap,
    title: "Expert Mentorship",
    description: "Guidance from professionals working in reputed companies who understand industry expectations."
  },
  {
    icon: Lightbulb,
    title: "Career Clarity & Direction",
    description: "Helping students identify the right path, skills, and opportunities for long-term growth."
  }
];

const services = [
  {
    icon: Brain,
    title: "Artificial Intelligence & Machine Learning",
    description: "Foundations of AI, ML concepts, real-world applications, and hands-on projects."
  },
  {
    icon: Code,
    title: "Programming & Core Computer Science",
    description: "Problem-solving, data structures, algorithms, and strong coding fundamentals."
  },
  {
    icon: Globe,
    title: "Web & Application Development",
    description: "Building modern, scalable applications using industry-relevant tools and frameworks."
  },
  {
    icon: Rocket,
    title: "Emerging Technologies & Tools",
    description: "Exposure to trending technologies shaping the future of the tech industry."
  },
  {
    icon: FolderOpen,
    title: "Project-Based Learning",
    description: "Real-world projects to apply concepts, build portfolios, and gain practical experience."
  }
];

function AnimatedSection({ children, className = "", delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
      transition={{ duration: 0.6, delay, ease: "easeOut" }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

function AnimatedDivider() {
  return (
    <div className="relative py-8 overflow-hidden">
      <div className="absolute inset-0 flex items-center justify-center">
        <motion.div 
          className="w-full h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent"
          initial={{ scaleX: 0, opacity: 0 }}
          whileInView={{ scaleX: 1, opacity: 1 }}
          transition={{ duration: 1.2, ease: "easeOut" }}
          viewport={{ once: true }}
        />
      </div>
      <div className="absolute inset-0 flex items-center justify-center">
        <motion.div
          className="w-3 h-3 bg-primary rounded-full"
          initial={{ scale: 0 }}
          whileInView={{ scale: 1 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          viewport={{ once: true }}
        />
      </div>
      <svg className="absolute inset-0 w-full h-full pointer-events-none" preserveAspectRatio="none">
        <motion.path
          d="M0,50 Q25,30 50,50 T100,50"
          fill="none"
          stroke="hsl(24 95% 53% / 0.2)"
          strokeWidth="1"
          className="w-full"
          initial={{ pathLength: 0 }}
          whileInView={{ pathLength: 1 }}
          transition={{ duration: 1.5, ease: "easeInOut" }}
          viewport={{ once: true }}
        />
      </svg>
    </div>
  );
}

function FloatingParticles() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {[...Array(6)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-primary/20 rounded-full"
          style={{
            left: `${15 + i * 15}%`,
            top: `${20 + (i % 3) * 25}%`,
          }}
          animate={{
            y: [0, -30, 0],
            x: [0, 10, 0],
            opacity: [0.2, 0.5, 0.2],
          }}
          transition={{
            duration: 4 + i,
            repeat: Infinity,
            ease: "easeInOut",
            delay: i * 0.5,
          }}
        />
      ))}
      {[...Array(4)].map((_, i) => (
        <motion.div
          key={`line-${i}`}
          className="absolute h-px bg-gradient-to-r from-transparent via-primary/10 to-transparent"
          style={{
            width: `${100 + i * 50}px`,
            left: `${10 + i * 20}%`,
            top: `${30 + i * 15}%`,
            transform: `rotate(${-15 + i * 10}deg)`,
          }}
          animate={{
            opacity: [0, 0.3, 0],
            x: [0, 50, 0],
          }}
          transition={{
            duration: 6 + i * 2,
            repeat: Infinity,
            ease: "easeInOut",
            delay: i * 1.5,
          }}
        />
      ))}
    </div>
  );
}

function AnimatedBackground() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      <motion.div
        className="absolute -top-1/2 -right-1/2 w-full h-full bg-gradient-radial from-primary/5 to-transparent rounded-full blur-3xl"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.5, 0.3],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute -bottom-1/2 -left-1/2 w-full h-full bg-gradient-radial from-orange-500/5 to-transparent rounded-full blur-3xl"
        animate={{
          scale: [1.2, 1, 1.2],
          opacity: [0.2, 0.4, 0.2],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <svg className="absolute inset-0 w-full h-full opacity-10" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
            <path d="M 60 0 L 0 0 0 60" fill="none" stroke="hsl(24 95% 53%)" strokeWidth="0.5" opacity="0.3" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
      </svg>
    </div>
  );
}

function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (href: string) => {
    setIsMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? "bg-background/90 backdrop-blur-md border-b border-border/50" 
          : "bg-transparent"
      }`}
    >
      <nav className="max-w-7xl mx-auto px-6 h-24 flex items-center justify-between gap-4">
        <button 
          onClick={() => scrollToSection("#home")}
          className="flex items-center gap-2 shrink-0"
          data-testid="link-logo"
        >
          <Logo size="md" />
        </button>

        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <button
              key={link.name}
              onClick={() => scrollToSection(link.href)}
              className="text-foreground/80 hover:text-primary transition-colors duration-200 font-medium"
              data-testid={`link-nav-${link.name.toLowerCase()}`}
            >
              {link.name}
            </button>
          ))}
        </div>

        <Button 
          className="hidden md:flex"
          onClick={() => scrollToSection("#contact")}
          data-testid="button-header-cta"
        >
          Get in Touch
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          data-testid="button-mobile-menu"
        >
          {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </Button>
      </nav>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-background/95 backdrop-blur-md border-b border-border"
          >
            <div className="px-6 py-4 flex flex-col gap-4">
              {navLinks.map((link) => (
                <button
                  key={link.name}
                  onClick={() => scrollToSection(link.href)}
                  className="text-left text-foreground/80 hover:text-primary transition-colors duration-200 font-medium py-2"
                  data-testid={`link-mobile-nav-${link.name.toLowerCase()}`}
                >
                  {link.name}
                </button>
              ))}
              <Button 
                className="w-full mt-2"
                onClick={() => scrollToSection("#contact")}
                data-testid="button-mobile-cta"
              >
                Get in Touch
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

function HeroSection() {
  const scrollToContact = () => {
    const element = document.querySelector("#contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center relative overflow-hidden pt-20" data-testid="section-hero">
      <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-primary/5" />
      <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 left-1/4 w-64 h-64 bg-primary/5 rounded-full blur-2xl" />
      
      <div className="max-w-7xl mx-auto px-6 py-20 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-center lg:text-left"
          >
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="inline-flex items-center gap-2 bg-primary/10 border border-primary/20 rounded-full px-4 py-2 mb-6"
            >
              <span className="w-2 h-2 bg-primary rounded-full animate-pulse" />
              <span className="text-sm font-medium text-primary">Empowering Future Tech Leaders</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6"
            >
              Empowering Students to Build{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-orange-400">
                Skills and Careers
              </span>{" "}
              Beyond Limits
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="text-lg md:text-xl text-muted-foreground mb-8 max-w-xl mx-auto lg:mx-0"
            >
              Industry-relevant tech courses, placement-focused training, and expert mentorship 
              to help students turn knowledge into real career opportunities.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
            >
              <Button 
                size="lg" 
                className="group text-lg px-8"
                onClick={scrollToContact}
                data-testid="button-hero-cta"
              >
                Get in Touch
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
            className="relative"
          >
            <div className="absolute -inset-4 bg-gradient-to-r from-primary/20 to-orange-400/20 rounded-2xl blur-2xl" />
            <div className="relative rounded-2xl overflow-hidden border border-primary/20">
              <img
                src={heroImage}
                alt="Professional mentor guiding a student in technology training"
                className="w-full h-auto object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/40 to-transparent" />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function AboutSection() {
  return (
    <section id="about" className="py-20 md:py-28 bg-card/50" data-testid="section-about">
      <div className="max-w-7xl mx-auto px-6">
        <AnimatedSection className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6">
            About <span className="text-primary">THEA Infinity</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Thea Infinity is a student-first technology and career guidance startup built with a 
            single mission — to bridge the gap between learning and real-world careers. We help 
            students gain industry-relevant technical skills, placement-oriented training, and 
            career clarity through mentorship from professionals working in reputed companies.
          </p>
        </AnimatedSection>

        <AnimatedSection delay={0.1} className="mb-12">
          <p className="text-center text-muted-foreground max-w-3xl mx-auto">
            Our programs are designed not just to teach concepts, but to prepare students for 
            real interviews, real projects, and real careers. At Thea Infinity, we believe 
            every student deserves the right guidance to grow beyond limits.
          </p>
        </AnimatedSection>

        <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
          {aboutPoints.map((point, index) => (
            <AnimatedSection key={point.title} delay={0.1 * (index + 1)}>
              <Card className="p-6 lg:p-8 h-full group hover:border-primary/30 transition-all duration-300 hover:-translate-y-1">
                <div className="flex items-start gap-4">
                  <div className="shrink-0 w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                    <point.icon className="w-7 h-7 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2" data-testid={`text-about-title-${index}`}>
                      {point.title}
                    </h3>
                    <p className="text-muted-foreground" data-testid={`text-about-desc-${index}`}>
                      {point.description}
                    </p>
                  </div>
                </div>
              </Card>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

function ServicesSection() {
  return (
    <section id="services" className="py-20 md:py-28" data-testid="section-services">
      <div className="max-w-7xl mx-auto px-6">
        <AnimatedSection className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6">
            Our <span className="text-primary">Services</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            We offer hands-on training in Artificial Intelligence and in-demand technologies, 
            with a strong focus on strong fundamentals, practical implementation, and real-world 
            industry use cases. Our programs are designed to help students build future-ready 
            skills through applied learning.
          </p>
        </AnimatedSection>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <AnimatedSection key={service.title} delay={0.1 * (index + 1)}>
              <Card className="p-6 h-full group hover:border-primary/30 transition-all duration-300 hover:-translate-y-1 relative overflow-visible">
                <div className="absolute -top-3 -right-3 w-20 h-20 bg-primary/5 rounded-full blur-xl group-hover:bg-primary/10 transition-colors" />
                <div className="relative">
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mb-4 group-hover:from-primary/30 group-hover:to-primary/10 transition-colors">
                    <service.icon className="w-7 h-7 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3" data-testid={`text-service-title-${index}`}>
                    {service.title}
                  </h3>
                  <p className="text-muted-foreground" data-testid={`text-service-desc-${index}`}>
                    {service.description}
                  </p>
                </div>
              </Card>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

function ContactSection() {
  const { toast } = useToast();
  
  const form = useForm<InsertContact>({
    resolver: zodResolver(insertContactSchema),
    defaultValues: {
      name: "",
      email: "",
      contact: "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: InsertContact) => {
      const response = await apiRequest("POST", "/api/contact", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Message Sent!",
        description: "Thank you for reaching out. We'll get back to you soon!",
      });
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertContact) => {
    mutation.mutate(data);
  };

  return (
    <section id="contact" className="py-20 md:py-28 bg-card/50" data-testid="section-contact">
      <div className="max-w-7xl mx-auto px-6">
        <AnimatedSection className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6">
            Ready to Start Your Journey{" "}
            <span className="text-primary">Beyond Limits?</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Get in touch with us for course details, mentorship, and career guidance.
          </p>
        </AnimatedSection>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <AnimatedSection delay={0.2} className="hidden lg:block">
            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-r from-primary/20 to-orange-400/20 rounded-2xl blur-2xl" />
              <div className="relative rounded-2xl overflow-hidden border border-primary/20">
                <img
                  src={contactImage}
                  alt="Students learning technology in a modern classroom"
                  className="w-full h-auto object-cover"
                  data-testid="img-contact-section"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent" />
              </div>
            </div>
          </AnimatedSection>

          <AnimatedSection delay={0.3}>
            <Card className="p-6 md:p-8">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter your name" 
                          {...field} 
                          data-testid="input-name"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input 
                          type="email" 
                          placeholder="Enter your email" 
                          {...field}
                          data-testid="input-email"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="contact"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contact Number</FormLabel>
                      <FormControl>
                        <Input 
                          type="tel" 
                          placeholder="Enter your contact number" 
                          {...field}
                          data-testid="input-contact"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  className="w-full" 
                  size="lg"
                  disabled={mutation.isPending}
                  data-testid="button-submit-contact"
                >
                  {mutation.isPending ? (
                    <span className="flex items-center gap-2">
                      <span className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                      Sending...
                    </span>
                  ) : (
                    "Send Message"
                  )}
                </Button>
              </form>
            </Form>
            </Card>
          </AnimatedSection>
        </div>
      </div>
    </section>
  );
}

function Footer({ onOpenPrivacy }: { onOpenPrivacy: () => void }) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="bg-card border-t border-border" data-testid="section-footer">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid md:grid-cols-3 gap-8 items-start">
          <div className="flex flex-col items-center md:items-start">
            <div className="mb-4" data-testid="img-footer-logo">
              <Logo size="lg" />
            </div>
            <p className="text-sm text-muted-foreground text-center md:text-left">
              Empowering students to build skills and careers beyond limits.
            </p>
          </div>

          <div className="flex flex-col items-center md:items-start gap-3">
            <h4 className="font-semibold mb-2" data-testid="text-footer-contact-heading">Contact Us</h4>
            <a 
              href="mailto:theainfinity2024@gmail.com" 
              className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
              data-testid="link-email"
            >
              <Mail className="w-4 h-4" />
              theainfinity2024@gmail.com
            </a>
            <a 
              href="tel:7845701961" 
              className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
              data-testid="link-phone"
            >
              <Phone className="w-4 h-4" />
              7845701961
            </a>
          </div>

          <div className="flex flex-col items-center md:items-end gap-4">
            <button
              onClick={onOpenPrivacy}
              className="text-muted-foreground hover:text-primary transition-colors underline-offset-4 hover:underline"
              data-testid="link-privacy-policy"
            >
              Privacy Policy
            </button>
            <Button
              variant="outline"
              size="icon"
              onClick={scrollToTop}
              className="rounded-full"
              data-testid="button-scroll-top"
            >
              <ChevronUp className="h-5 w-5" />
            </Button>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-border text-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} THEA Infinity. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}

function PrivacyPolicyModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">Privacy Policy</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 text-sm text-muted-foreground">
          <p className="text-xs">Last updated: Dec 13, 2025</p>
          
          <p>
            At Thea Infinity, we value your trust and are committed to protecting your personal 
            information. This Privacy Policy explains how we collect, use, store, and safeguard 
            your data when you visit our website or use our services.
          </p>

          <div>
            <h3 className="text-lg font-semibold text-foreground mb-3">1. Information We Collect</h3>
            <p className="mb-2">We may collect the following types of information:</p>
            <h4 className="font-medium text-foreground mb-2">a. Personal Information</h4>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Name</li>
              <li>Email address</li>
              <li>Phone number</li>
              <li>Educational details (college, course, year, etc.)</li>
              <li>Any information you voluntarily provide through forms or inquiries</li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-foreground mb-3">2. How We Use Your Information</h3>
            <p className="mb-2">We use your information to:</p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Provide details about our courses, training, and mentorship programs</li>
              <li>Respond to inquiries and support requests</li>
              <li>Improve our website, services, and learning experience</li>
              <li>Communicate updates, offers, or important information (only if opted in)</li>
              <li>Ensure platform security and prevent misuse</li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-foreground mb-3">3. Data Sharing & Disclosure</h3>
            <p className="mb-2">We do not sell, trade, or rent your personal information to third parties.</p>
            <p className="mb-2">Your data may be shared only:</p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>With trusted service providers strictly for operational purposes</li>
              <li>When required by law or legal authorities</li>
              <li>To protect the rights, safety, or property of Thea Infinity and its users</li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-foreground mb-3">4. Data Security</h3>
            <p>
              We implement reasonable technical and organizational measures to protect your personal 
              information against unauthorized access, loss, misuse, or alteration.
            </p>
            <p className="mt-2">
              However, no method of transmission over the internet is 100% secure, and we cannot 
              guarantee absolute security.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-foreground mb-3">5. Cookies & Tracking Technologies</h3>
            <p className="mb-2">Our website may use cookies to:</p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Improve user experience</li>
              <li>Analyze website traffic and performance</li>
            </ul>
            <p className="mt-2">
              You can choose to disable cookies through your browser settings if you prefer.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-foreground mb-3">6. Third-Party Links</h3>
            <p>
              Our website may contain links to third-party websites. We are not responsible for the 
              privacy practices or content of those external sites.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-foreground mb-3">7. Contact Us</h3>
            <p>
              If you have any questions or concerns about this Privacy Policy or your data, please 
              contact us at:
            </p>
            <p className="mt-2 font-medium text-foreground">
              Email: theainfinity2024@gmail.com
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function Home() {
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background relative">
      <AnimatedBackground />
      <FloatingParticles />
      <Header />
      <main className="relative z-10">
        <HeroSection />
        <AnimatedDivider />
        <AboutSection />
        <AnimatedDivider />
        <ServicesSection />
        <AnimatedDivider />
        <ContactSection />
      </main>
      <Footer onOpenPrivacy={() => setIsPrivacyOpen(true)} />
      <PrivacyPolicyModal isOpen={isPrivacyOpen} onClose={() => setIsPrivacyOpen(false)} />
    </div>
  );
}
