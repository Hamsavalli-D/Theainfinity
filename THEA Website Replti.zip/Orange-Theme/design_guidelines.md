# THEA Infinity Design Guidelines

## Design Approach
**Reference-Based**: Drawing inspiration from modern educational tech platforms (Coursera, Udemy) combined with startup energy (Linear, Stripe) to create a vibrant, student-focused experience that balances professionalism with dynamic energy.

## Core Design Principles
1. **Vibrant Energy**: Bold, animated elements that capture student attention
2. **Professional Clarity**: Clean layouts that build trust with both students and parents
3. **Action-Oriented**: Prominent CTAs and clear pathways to engagement
4. **Motion-Rich**: Smooth transitions and hover states throughout

## Typography System
- **Primary Font**: Poppins (Google Fonts) for headings - bold, modern, friendly
- **Secondary Font**: Inter (Google Fonts) for body text - clean, readable
- **Hierarchy**:
  - Hero Headline: text-5xl to text-7xl, font-bold
  - Section Headers: text-4xl to text-5xl, font-semibold
  - Subsections: text-2xl to text-3xl, font-medium
  - Body Text: text-base to text-lg
  - Small Text/Labels: text-sm

## Layout System
**Spacing Primitives**: Use Tailwind units of 4, 6, 8, 12, 16, 20 (e.g., p-4, gap-8, mb-12)
- Section Padding: py-16 to py-24 on desktop, py-12 on mobile
- Container: max-w-7xl with px-6 to px-8
- Component Spacing: gap-8 for grids, space-y-6 for vertical stacks

## Component Library

### Header/Navigation
- Fixed position navbar with blur background on scroll
- Logo left-aligned, navigation links right-aligned
- Smooth scroll behavior to sections
- Mobile: Hamburger menu with slide-in drawer
- Height: h-20 with logo at h-12

### Hero Section
- Full-screen impact: min-h-screen with centered content
- Two-column layout on desktop: 60% text, 40% image
- Image: Professional photo of student being mentored in modern office setting (bright, optimistic lighting)
- Prominent "Get in Touch" CTA with gradient hover effect and subtle scale animation
- Floating/animated accent elements (subtle geometric shapes in orange)

### About Section
- Four key points displayed as cards in 2x2 grid (desktop), stacked on mobile
- Each card: Icon/simple illustration at top, title, description
- Cards have subtle lift on hover with shadow increase
- Background: Alternating section treatment (light vs slightly darker)

### Services Section
- Five service areas in masonry-style card layout
- Cards feature: Icon header, bold title, concise description
- Staggered animation on scroll-into-view
- Hover: Gentle glow effect around cards with scale transform

### Contact Section
- Centered layout with prominent heading
- Form: Single column, generous spacing between fields
- Input fields: Clean, modern with subtle borders, focus states with orange accent
- Submit button: Large, prominent with loading state animation
- Background: Subtle gradient or geometric pattern

### Footer
- Three-column layout: Logo + tagline | Contact info | Privacy Policy
- Social links with icon hover animations
- Minimal height, clean separation from main content

### Privacy Policy Modal
- Overlay with backdrop blur
- Centered card with close button (X icon top-right)
- Scrollable content area within modal
- Smooth fade-in/out animation

## Animation Strategy
**Purposeful Motion** - Use sparingly but impactfully:
- Page load: Staggered fade-in of hero elements (250ms delays)
- Scroll animations: Fade-up on section entry using Intersection Observer
- Hover states: Scale (1.02-1.05), shadow depth, subtle color shifts
- CTA buttons: Gradient shimmer on hover, gentle pulse
- Card interactions: Lift with shadow (translateY -2 to -4px)
- Transitions: 200-300ms with ease-in-out

## Images
**Hero Section**: High-quality photograph showing a professional mentor (standing/sitting) guiding a student at a laptop/whiteboard in a modern, bright workspace. Conveys collaboration, professionalism, and growth. Ratio: 4:3 or square.

**About Section Icons**: Use Heroicons (outline style) - academic-cap, chart-bar, users, light-bulb for the four key points.

**Services Section**: Subtle animated icons or illustrations for each service area (AI/brain icon, code brackets, globe/web, rocket/trending, folder/project). Consider Lottie animations for lightweight motion.

## Responsive Breakpoints
- Mobile: base (< 768px) - single column, stacked layouts
- Tablet: md (768px+) - 2 columns where appropriate
- Desktop: lg (1024px+) - full multi-column layouts
- Wide: xl (1280px+) - max container width enforced

## Interactive Elements
- All clickable elements: Clear hover/active states
- Form inputs: Focus ring in orange, validation states
- Buttons: Primary (orange), Secondary (outlined), hover scale + shadow
- Links: Underline on hover with smooth transition
- Cards: Lift + shadow on hover

## Accessibility
- Semantic HTML throughout
- ARIA labels for interactive elements
- Keyboard navigation support
- Form labels and error messages
- Sufficient color contrast (verify black/orange combinations)
- Focus indicators visible and styled

This design creates a vibrant, engaging experience that appeals to students while maintaining professional credibility for career-focused guidance.